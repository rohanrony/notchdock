NotchDock demo clips
Official website: https://notchdock.app
Media page: https://notchdock.app/media/
Support: notchdock@gmail.com

Five demos, each square (1080x1080) and vertical (1080x1920), with JPEG posters and SRT captions. Silent H.264 MP4s at original speed; no added audio or loops.

Match details: 11.5 seconds; historical result/statistics.
Timer start: 12 seconds; basic two-minute countdown, compact view and reopen.
Task completion: 10 seconds; sample task entry, reorder and completion.
Stock chart ranges: 12.5 seconds; watchlist, range change and indices.
Three useful moments: 22 seconds; separate edited task, timer and match excerpts.

Recorded demos: scores and prices are historical. These clips show an earlier interface; exact UI may differ from the current beta. The timer excerpt does not demonstrate a full Pomodoro work/break cycle. Original ScreenKite watermark retained.

NotchDock is free during its current public beta and requires macOS 14 or newer. For current features, installation, permissions and limits, use the official website and release notes. Independent reviewers should test the current release.

clip-manifest.json lists output checksums, dimensions and durations. No personal notes/calendar footage, original master, private campaign records or posting drafts are included.
